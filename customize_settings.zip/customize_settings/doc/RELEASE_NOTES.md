## Module <customize_settings>

#### 25.04.2021
#### Version 14.0.1.0.0
#### ADD
Initial Commit for customize_settings

#### 03.05.2021
#### Version 14.0.1.1.1
#### UPDT
Restored Odoo Copyright in Settings
