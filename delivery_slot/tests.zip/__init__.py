# -*- coding: utf-8 -*-
from . import test_slot_time
from . import test_delivery_slot
from . import test_res_config_settings
from . import test_sale_order
from . import test_stock_move
