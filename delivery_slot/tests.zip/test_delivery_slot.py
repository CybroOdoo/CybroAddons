# -*- coding: utf-8 -*-
#############################################################################
#
#    Cybrosys Technologies Pvt. Ltd.
#
#    Copyright (C) 2026-TODAY Cybrosys Technologies(<https://www.cybrosys.com>)
#
#    You can modify it under the terms of the GNU AFFERO
#    GENERAL PUBLIC LICENSE (AGPL v3), Version 3.
#
#############################################################################
from datetime import date, timedelta
from odoo.exceptions import ValidationError
from odoo.tests.common import TransactionCase


class TestDeliverySlot(TransactionCase):
    """Test cases for the delivery.slot model."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.DeliverySlot = cls.env['delivery.slot']
        cls.SlotTime = cls.env['slot.time']

        cls.slot_time_morning = cls.SlotTime.create({
            'name': 'Morning 8-12',
            'time_from': '8',
            'time_to': '12',
        })
        cls.slot_time_afternoon = cls.SlotTime.create({
            'name': 'Afternoon 13-17',
            'time_from': '13',
            'time_to': '17',
        })
        cls.future_date = date.today() + timedelta(days=3)
        cls.future_date2 = date.today() + timedelta(days=4)

    # -------------------------------------------------------------------------
    # Creation Tests
    # -------------------------------------------------------------------------

    def test_create_delivery_slot_defaults(self):
        """Test that default values are applied correctly on creation."""
        slot = self.DeliverySlot.create({
            'delivery_date': self.future_date,
            'slot_id': self.slot_time_morning.id,
        })
        self.assertEqual(slot.delivery_limit, 100,
                         "Default delivery_limit should be 100")
        self.assertTrue(slot.active, "Slot should be active by default")

    def test_create_delivery_slot_with_custom_limit(self):
        """Test creating a delivery slot with a custom delivery limit."""
        slot = self.DeliverySlot.create({
            'delivery_date': self.future_date,
            'slot_id': self.slot_time_morning.id,
            'delivery_limit': 50,
        })
        self.assertEqual(slot.delivery_limit, 50)

    def test_create_delivery_slot_inactive(self):
        """Test creating a delivery slot in inactive state."""
        slot = self.DeliverySlot.create({
            'delivery_date': self.future_date,
            'slot_id': self.slot_time_morning.id,
            'active': False,
        })
        self.assertFalse(slot.active)

    # -------------------------------------------------------------------------
    # SQL Constraint: Unique (delivery_date, slot_id)
    # -------------------------------------------------------------------------

    def test_unique_date_slot_constraint(self):
        """Test that the same date+slot combination cannot be created twice."""
        self.DeliverySlot.create({
            'delivery_date': self.future_date,
            'slot_id': self.slot_time_morning.id,
        })
        with self.assertRaises(Exception):
            self.DeliverySlot.create({
                'delivery_date': self.future_date,
                'slot_id': self.slot_time_morning.id,
            })

    def test_same_date_different_slot_allowed(self):
        """Test that the same date with a different slot is allowed."""
        slot1 = self.DeliverySlot.create({
            'delivery_date': self.future_date,
            'slot_id': self.slot_time_morning.id,
        })
        slot2 = self.DeliverySlot.create({
            'delivery_date': self.future_date,
            'slot_id': self.slot_time_afternoon.id,
        })
        self.assertNotEqual(slot1.id, slot2.id)

    def test_same_slot_different_date_allowed(self):
        """Test that the same slot on different dates is allowed."""
        slot1 = self.DeliverySlot.create({
            'delivery_date': self.future_date,
            'slot_id': self.slot_time_morning.id,
        })
        slot2 = self.DeliverySlot.create({
            'delivery_date': self.future_date2,
            'slot_id': self.slot_time_morning.id,
        })
        self.assertNotEqual(slot1.id, slot2.id)

    # -------------------------------------------------------------------------
    # Computed Field: total_delivery
    # -------------------------------------------------------------------------

    def test_total_delivery_zero_with_no_orders(self):
        """Test that total_delivery is 0 when no sale orders are linked."""
        slot = self.DeliverySlot.create({
            'delivery_date': self.future_date,
            'slot_id': self.slot_time_morning.id,
        })
        self.assertEqual(slot.total_delivery, 0)

    # -------------------------------------------------------------------------
    # Computed Field: remaining_slots
    # -------------------------------------------------------------------------

    def test_remaining_slots_equals_limit_when_no_deliveries(self):
        """Test remaining_slots equals delivery_limit with no orders."""
        slot = self.DeliverySlot.create({
            'delivery_date': self.future_date,
            'slot_id': self.slot_time_morning.id,
            'delivery_limit': 30,
        })
        self.assertEqual(slot.remaining_slots, 30)

    def test_remaining_slots_decrements_with_total_delivery(self):
        """Test remaining_slots = delivery_limit - total_delivery."""
        slot = self.DeliverySlot.create({
            'delivery_date': self.future_date,
            'slot_id': self.slot_time_morning.id,
            'delivery_limit': 10,
        })
        # Patch total_delivery by writing it directly via the ORM override
        slot.write({'delivery_limit': 10})
        # remaining_slots is computed from delivery_limit - total_delivery
        # With no orders, total_delivery = 0, so remaining = 10
        self.assertEqual(slot.remaining_slots, slot.delivery_limit - slot.total_delivery)

    # -------------------------------------------------------------------------
    # _rec_name
    # -------------------------------------------------------------------------

    def test_display_name_uses_delivery_date(self):
        """Test that the record name (display_name) uses delivery_date."""
        slot = self.DeliverySlot.create({
            'delivery_date': self.future_date,
            'slot_id': self.slot_time_morning.id,
        })
        # _rec_name = 'delivery_date', so name_get should return the date
        display = slot.display_name
        self.assertIn(str(self.future_date), display)

    # -------------------------------------------------------------------------
    # _get_pending_delivery_orders helper
    # -------------------------------------------------------------------------

    def test_get_pending_delivery_orders_no_slot_or_date(self):
        """Test _get_pending_delivery_orders returns empty recordset when
        delivery_date or slot_id is missing."""
        slot = self.DeliverySlot.create({
            'delivery_date': self.future_date,
            'slot_id': self.slot_time_morning.id,
        })
        # Temporarily clear slot_id to test early return
        slot_no_slot = self.DeliverySlot.new({})
        orders = slot_no_slot._get_pending_delivery_orders()
        self.assertFalse(orders, "Should return empty recordset when no date/slot")

    # -------------------------------------------------------------------------
    # active / deactivate toggle
    # -------------------------------------------------------------------------

    def test_deactivate_delivery_slot(self):
        """Test deactivating a delivery slot."""
        slot = self.DeliverySlot.create({
            'delivery_date': self.future_date,
            'slot_id': self.slot_time_morning.id,
        })
        self.assertTrue(slot.active)
        slot.write({'active': False})
        self.assertFalse(slot.active)

    def test_reactivate_delivery_slot(self):
        """Test reactivating an inactive delivery slot."""
        slot = self.DeliverySlot.create({
            'delivery_date': self.future_date,
            'slot_id': self.slot_time_morning.id,
            'active': False,
        })
        slot.with_context(active_test=False).write({'active': True})
        self.assertTrue(slot.active)

    # -------------------------------------------------------------------------
    # Update delivery_limit
    # -------------------------------------------------------------------------

    def test_update_delivery_limit(self):
        """Test updating delivery_limit updates remaining_slots accordingly."""
        slot = self.DeliverySlot.create({
            'delivery_date': self.future_date,
            'slot_id': self.slot_time_morning.id,
            'delivery_limit': 10,
        })
        slot.write({'delivery_limit': 25})
        self.assertEqual(slot.delivery_limit, 25)
        self.assertEqual(slot.remaining_slots, 25 - slot.total_delivery)

    # -------------------------------------------------------------------------
    # Model metadata
    # -------------------------------------------------------------------------

    def test_model_name(self):
        """Test that the model technical name is correct."""
        self.assertEqual(self.env['delivery.slot']._name, 'delivery.slot')

    def test_model_description(self):
        """Test that the model description is correct."""
        self.assertEqual(
            self.env['delivery.slot']._description, 'Delivery slot')
